# Smoke Aerosol Measurement Experiment-Reflight

| Field | Value |
|---|---|
| PSI ID | PSI-101 (version 4) |
| Acronym | SAME-R |
| DOI | [10.60555/2np7-jv14](https://doi.org/10.60555/2np7-jv14) |
| PSI page | https://psi.nasa.gov/physci/repo/data/investigations/PSI-101 |
| Research area | Combustion Science — Spacecraft Fire Safety |
| Project type | Microgravity Investigation |
| Proposal title |  |
| Flight platform | International Space Station (ISS) |
| Sponsor / program | National Aeronautics and Space Administration (NASA) |
| NASA center | Glenn Research Center (GRC) |
| Hardware | Comparitive Soot Diagnostic Hardware; Refer to final report |
| Investigation dates | 07-01-2010 to 09-30-2010 |
| Funding |  |
| Released / submitted | 18-Sep-2024 / 18-Sep-2024 |
| License | Creative Commons Zero v1.0 Universal |
| Total data size | 5.9 GB across 344 files |

## Objectives

Similar to the original SAME investigation, the primary objective of the SAME-R investigation was to quantify the sizes that the liquid smoke particulate achieves in low gravity and to relate the droplet size distribution to the smoke generation and smoke transport conditions in the experiment. One of the problems encountered during the SAME investigation was that after the thermal precipitators were returned to the ground, it was found that all the TEM grids were severely contaminated with some unidentified foreign particles, making these grids unusable although some of them showed shapes of certain types of smoke particles. Based on that experience the SAME-R investigation employed several modification covering new materials, extended operating conditions, and diagnostic equipments.

## Approach

SAME-R utilized the SAME hardware used on-orbit. Based on the experience gained from SAME, SAME-R included the following modifications: 1) a new test material,
Pyrell®, an intumescent fire-retardant foam by Foamex, was introduced to replace DBP samples, 2) test conditions were broadened including higher heating temperatures and no-flow during sample heating time, and 3) a new instrument, M-pass, developed in-house GRC, was used to replace one of the two Commercial Diagnostic Enclosures that includes a DustTrak and an ionization detector used in SAME. SAME-R flight tests were conducted from July 16, to September 9, 2010, successfully completing 66 test points. After SAME-R flight tests, three major post–flight ground tests were performed to improve data reduction process and to validate the lognormal distribution assumption, the key to the moment method employed by SAME and SAME-R.

## Hypothesis

The three hypotheses that motivated the original SAME investigation is also applicable for the reflight SAME-R investigation:
In a μg environment, with the absence of the strong buoyancy-induced flows, smoke particle growth from a pyrolyzing/smoldering source, as a result of nucleation, condensation, and coagulation, will lead to larger particles compared to those produced in 1g. The formation of the larger particles is favored by the expected higher vapor concentration and smoke residence times near the source due to the reduced velocities and mixing at μg conditions. In particular, it is hypothesized that liquid aerosol smokes produced in microgravity will exhibit substantially larger droplet sizes than under the same conditions in normal gravity (with a corresponding decrease in the particle number density for the same mass of smoke). The change in the size distribution and number density will, in turn, affect the response of the smoke detectors and possibly result in some detectors not producing an alarm when exposed to this smoke.

## Research impacts / Earth benefits

Along with the results from the original SAME investigation, the results from SAME-R can lead to technology for an advanced fire detector for future spacecraft that will be used for long duration missions. SAME will provide quantitative data on the sensitivity of these detectors to reduced gravity smokes that will allow evaluation of the adequacy of these existing technologies using relevant data. The current Fire Prevention, Detection, and Suppression (FPDS) program plan allows for the re-evaluation of future sensor technology, to allow new technology and capability to be utilized. The results from SAME are needed to provide the reduced gravity baseline data against which future detection technology developments can be evaluated. The smoke detectors developed from the results of SAME can also be useful in other extreme environments on Earth, such as submarines or underwater laboratories. Accurate detection of smoke in these environments can save lives.

## Contacts

- Zeng-guang Yuan — NASA GRC (Co-Investigator (Co-I))
- Claire Fortenberry — NASA GRC (Project Scientist)
- David Urban — NASA GRC (Principal Investigator (PI))
- Jiann C Yang — National Institute for Standards and Technology (NIST) (Co-Investigator (Co-I))
- Thomas Cleary — National Institute for Standards and Technology (NIST) (Co-Investigator (Co-I))
- George W Mulholland — University of Maryland (Co-Investigator (Co-I))

## Experiment Table

- `experiment_table/PSI-101_Experimental table_SAME-R.csv`

## Representative image

`representative_image.jpg` — Still frame extracted from flight video Raw Data/PSI-101_Raw Data_2 Kapton vlc-record-2010-09-07-17h19m24s-udp___233.1.14.11 _50300-.mp4 (frame at 89.5s). Not an official PSI representative image.

## Data files (not downloaded — listing only)

| Folder | Files | Size |
|---|---|---|
| Analyzed Data | 86 | 472.2 MB |
| Engineering Documents | 24 | 52.6 MB |
| Experimental table | 1 | 5.5 KB |
| Presentations | 4 | 31.8 MB |
| Raw Data | 223 | 5.3 GB |
| Reference Data | 2 | 655.6 KB |
| Reports | 1 | 4.4 MB |
| Science Documents | 2 | 924.9 KB |
| metadata | 1 | 10.8 KB |

## Publications (6)

1. **Smoke Aerosol Measurement Experiment-2: Comparison of Flight Experiment Results with Ground Test Results** — Meyer Marit E., Urban David L., Ruff Gary A., Mulholland George, Yuan Zeng-guang, Bryg Victoria, Cleary Thomas, Yang Jiann — DOI: [10.2514/6.2013-3433](https://doi.org/10.2514/6.2013-3433)
2. **Evaluation of Low-Gravity Smoke Particulate for Spacecraft Fire Detection** — D Urban, G Ruff, G Mulholland, M Meyer, ZG Yuan, T Cleary, J Yang, P Greenberg, V Bryg
3. **Particle Morphology and Size Results from the Smoke Aerosol Measurement Experiment-2** — Urban David, Ruff Gary, Greenberg Paul, Fischer David, Meyer Marit, Mulholland George, Yuan Zeng-guang, Bryg Victoria, Cleary Thomas, Yang Jiann — DOI: [10.2514/6.2012-3536](https://doi.org/10.2514/6.2012-3536)
4. **Preliminary Results from the Smoke Aerosol Measurement Experiment - Reflight** — D Urban, G Ruff, M Meyer, T Cleary, J Yang, G Mulholland, ZG Yuan, V Bryg
5. **Detection of Smoke from Microgravity Fires** — DL Urban, D Griffin, G Ruff, T Cleary, J Yang, G Mulholland, ZG Yuan
6. **Evaluation of spacecraft smoke detector performance in the low-gravity environment** — Meyer Marit E., Urban David L., Mulholland George W., Bryg Victoria, Yuan Zeng-Guang, Ruff Gary A., Cleary Thomas, Yang Jiann — DOI: [10.1016/j.firesaf.2018.04.004](https://doi.org/10.1016/j.firesaf.2018.04.004)

---
Source: NASA Physical Sciences Informatics (PSI). Cite with DOI 10.60555/2np7-jv14. Retrieved 2026-11-14.
