# Advanced Combustion via Microgravity Experiments - Burning Rate Emulator

| Field | Value |
|---|---|
| PSI ID | PSI-20 (version 4) |
| Acronym | ACME BRE |
| DOI | [10.60555/vb93-3y72](https://doi.org/10.60555/vb93-3y72) |
| PSI page | https://psi.nasa.gov/physci/repo/data/investigations/PSI-20 |
| Research area | Combustion Science — Flames of Gaseous Fuels |
| Project type | Microgravity Investigation |
| Proposal title | Experimental Investigation of Emulated Burning Rate at Various Gravity Levels |
| Flight platform | International Space Station (ISS) |
| Sponsor / program | National Aeronautics and Space Administration (NASA) |
| NASA center | Glenn Research Center (GRC) |
| Hardware | Combustion Integrated Rack (CIR), ACME |
| Investigation dates | 01-01-2010 to 02-08-2025 |
| Funding | NNX10AD98G, NNX15AD06A, 80NSSC20M0119 |
| Released / submitted | 15-Sep-2022 / 15-Sep-2022 |
| License | Creative Commons Zero v1.0 Universal |
| Total data size | 1.9 TB across 2361 files |

## Objectives

The BRE flight program seeks to establish the burning conditions in a quiescent microgravity ambient in terms of material properties.
The specific flight objectives are as follows.
  1. Observe burning behavior in long-duration microgravity for CH4/N2 and C2H4/N2mixtures on porous circular burners of 25  and 50 mm diameter. Consider O2/N2 ambients with various pressures and ambient O2 concentrations and pressures. NASA - considered atmosphere for human space missions will be examined: 14.7 psia, 21 % oxygen: 10.2 psia, 26.5 %; and 8.2 psia, 34 % oxygen. Emphasize fuel conditions that can be related to a diverse range of condensed fuels.
  2. Consider the conditions of Objective 1 for ambients of O2/CO2 (desired).
  3. Consider the conditions of Objectives 1 – 2 for extinction limits.

## Approach

To accomplish the above objectives, flight experiments are proposed. Additionally, preliminary flight tests will be performed to verify the experiment operations and for comparison with ground-based tests.

For each test, conditions will be established for the chamber contents, namely choice of diluent, oxygen concentration, and pressure. Fuel flow will commence followed by ignition. The flames will initially be observed without varying the fuel flow rate. Because burner surface temperature and heat flux will vary, this will allow a broad range of conditions to be observed during a single test. As the surface temperature of the burner increases, and the flame remains steady, a continuous set of data is produced for the flammability map. Eventually either the flame will extinguish, the surface temperature of the burner will equilibrate, or the temperature limit of the heat flux sensor will be reached. At this time the fuel flow will be terminated. So a test should terminate for a given flow rate at extinction, and for continued burning when the burner surface temperature has steadied or the temperature limit of the heat flux sensor is neared.

The extinction limit could be found once the burner temperature has steadied, and the heat flux sensor has not exceeded its limit. At that state, the flow rate can be reduced in small increments, until extinction is observed and the flow rate shut off. Again, in this process, new data is being produced for the flammability map. Ignition limit tests are not proposed for microgravity, but we will explore these under normal gravity. We believe there is better control on Earth-based ignition testing and that these results should carry over to microgravity conditions.

In addition to the flight experiments, in normal gravity testing will continue. These tests will involve gaseous, liquid, and solid fuels. These experiments will further establish the validation of the BRE for 1-g applications and show its usefulness to establish 1-g ignition and extinction limits. As available, drop facility testing will be used to refine procedures, test instrumentation, and help to establish viable flow conditions.

We will also pursue a CFD model for the quiescent microgravity burning. This will also guide us in the flight experiments, and potentially provide a predictive methodology.

## Hypothesis

The BRE investigation hypothesizes that there can exist a regime of quasi-steady burning in microgravity as a function of materials properties. Steady burning may never be achieved, and only slowly changing unsteady flames are possible. The proposed tests aboard the ISS aims to query this hypothesis by establishing a range of quasi-steady burning conditions for condensed fuels in the microgravity environment. It is hypothesized that BRE can determine a range of burning conditions in microgravity as a function of heat of gasification, reradiation heat flux, applied radiant heat flux, heat of combustion and smoke point. This could enable the Cone Calorimeter (NASA Test 2) test as a basis for establishing flammability maps for real materials.

The key hypothesis is that the heat of combustion, smoke point, and heat of gasification of the fuel mixture will represent a real solid fuel (or liquid fuel absorbed in an inert matrix). Thus achieved steady burning would represent the potential for real solid fuels to achieve steady burning in microgravity. Other than a candle flame, this has not been shown before.

## Research impacts / Earth benefits

BRE yielded important data relevant to spacecraft fire safety. Quasi-steady burning corresponding to various condensed-phase materials (such as PMMA and Nylon) was observed in microgravity despite the absence of air flow, where the cessation of ventilation is an established step in putting out spacecraft fires. The ongoing combustion without air flow was notably seen in elevated-oxygen atmospheres which are being considered for use in future spacecraft, whereas such flames in a normal atmosphere of 21% oxygen self-extinguished in a short time. While BRE’s results are still preliminary, they suggest that NASA may want to increase use of its alternative flammability Test 2, with the cone calorimeter, where that test can measure material properties corresponding to the microgravity flames observed with the BRE burner.

## Contacts

- John L de Ris (Co-Investigator (Co-I))
- Peter Sunderland — University of Maryland (Project Scientist)
- James G. Quintiere — University of Maryland (Principal Investigator (PI))
- Dennis Stocker — NASA GRC (Project Scientist)

## Experiment Table

- `experiment_table/PSI-20_Experimental table_ACME BRE.csv`

## Representative image

`representative_image.jpg` — Still frame extracted from flight video Raw Data/PSI-20_Raw Data_vlc-record-2019-03-28-17h57m52s-udp____19087C1.mp4 (frame at 127.5s). Not an official PSI representative image.

## Data files (not downloaded — listing only)

| Folder | Files | Size |
|---|---|---|
| Engineering Documents | 25 | 153.9 MB |
| Experimental table | 1 | 1.1 KB |
| Presentations | 13 | 175.8 MB |
| Raw Data | 2297 | 1.9 TB |
| Reports | 2 | 17.5 MB |
| Science Documents | 22 | 68.8 MB |
| metadata | 1 | 14.7 KB |

## Publications (16)

1. **Burning on flat wicks at various orientations** — Zhang Yi, Bustamante Michael J, Gollner Michael J, Sunderland Peter B, Quintiere James G — DOI: [10.1177/0734904113495650](https://doi.org/10.1177/0734904113495650)
2. **A Gas Burner to Emulate Condensed-Phase Burning** — Zhang Y., Bustamante M. J., Dotson K. T., Sunderland P. B., Quintiere J. G. — DOI: [10.3850/978-981-07-5936-0_03-01](https://doi.org/10.3850/978-981-07-5936-0_03-01)
3. **Experimental Investigation of Liquid and Gas Fueled Flames Towards the Development of a Burning Rate Emulator (BRE) for Microgravity Applications** — MJ Bustamante
4. **Burning in microgravity: Experimental results and analysis** — P Dehghani, PB Sunderland, JG Quintiere, JL deRis — DOI: [10.1016/j.combustflame.2021.01.035](https://doi.org/10.1016/j.combustflame.2021.01.035)
5. **Transient dynamics of radiative extinction in low-momentum microgravity diffusion flames** — Snegirev Alexander, Kuznetsov Egor, Markus Ekaterina, Dehghani Parham, Sunderland Peter — DOI: [10.1016/j.proci.2020.06.110](https://doi.org/10.1016/j.proci.2020.06.110)
6. **Emulation of condensed fuel flames with gaseous fuels supplied through a porous copper calorimeter** — Auth Eric, Quintiere James G., Sunderland Peter B. — DOI: [10.1002/fam.2896](https://doi.org/10.1002/fam.2896)
7. **Radiative Extinction of Laminar Diffusion Flame above the Flat Porous Burner in Microgravity: A Computational Study** — Kuznetsov E. A., Snegirev A. Yu., Markus E. S. — DOI: [10.1134/S0010508220040036](https://doi.org/10.1134/S0010508220040036)
8. **Transient ellipsoidal combustion model for a porous burner in microgravity** — Markan Akshit, Baum Howard R., Sunderland Peter B., Quintiere James G., de Ris John L. — DOI: [10.1016/j.combustflame.2019.09.030](https://doi.org/10.1016/j.combustflame.2019.09.030)
9. **Measuring heat flux to a porous burner in microgravity** — Markan Akshit, Sunderland Peter B., Quintiere James G., de Ris John L., Baum Howard R. — DOI: [10.1016/j.proci.2018.05.006](https://doi.org/10.1016/j.proci.2018.05.006)
10. **Analysis of extinction and sustained ignition** — Vermina Plathner Frida, Quintiere James G., van Hees Patrick — DOI: [10.1016/j.firesaf.2019.02.003](https://doi.org/10.1016/j.firesaf.2019.02.003)
11. **A Burning Rate Emulator (BRE) for study of condensed fuel burning in microgravity** — Markan Akshit, Sunderland Peter B., Quintiere James G., de Ris John L., Stocker Dennis P., Baum Howard R. — DOI: [10.1016/j.combustflame.2018.01.044](https://doi.org/10.1016/j.combustflame.2018.01.044)
12. **Study of ignition and extinction of small-scale fires in experiments with an emulating gas burner** — Lundström Frida Vermina, Sunderland Peter B., Quintiere James G., van Hees Patrick, de Ris John L. — DOI: [10.1016/j.firesaf.2016.11.003](https://doi.org/10.1016/j.firesaf.2016.11.003)
13. **Emulation of condensed fuel flames with gases in microgravity** — Zhang Yi, Kim Matt, Guo Haiqing, Sunderland Peter B., Quintiere James G., deRis John, Stocker Dennis P. — DOI: [10.1016/j.combustflame.2015.05.005](https://doi.org/10.1016/j.combustflame.2015.05.005)
14. **Flammability maps for microgravity burning of a small flat material in a quiescent ambient** — Dehghani Parham, Quintiere James G. — DOI: [10.1016/j.combustflame.2023.112809](https://doi.org/10.1016/j.combustflame.2023.112809)
15. **Demonstrating steady burning for small flat materials in microgravity in a quiescent ambient** — Dehghani Parham, de Ris John L., Quintiere James G. — DOI: [10.1016/j.proci.2022.08.107](https://doi.org/10.1016/j.proci.2022.08.107)
16. **Theoretical analysis and predictions of burning in microgravity using a burning emulator** — Dehghani Parham, Quintiere James G. — DOI: [10.1016/j.combustflame.2021.111572](https://doi.org/10.1016/j.combustflame.2021.111572)

---
Source: NASA Physical Sciences Informatics (PSI). Cite with DOI 10.60555/vb93-3y72. Retrieved 2026-11-14.
